class Room < ApplicationRecord

  belongs_to :department, class_name: 'Department', dependent: :destroy

  has_many :events, class_name: 'Event', dependent: :destroy

  has_many :user, class_name: 'User', dependent: :destroy

  validates :name, presence: true
  validates :room_type, presence: true

end

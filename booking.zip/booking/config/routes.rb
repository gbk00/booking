Rails.application.routes.draw do
  get 'booking/index'

  resources :events

  root 'booking#index'
end

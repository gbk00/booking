class Department < ApplicationRecord

  belongs_to :office, class_name: 'Office', dependent: :destroy

  has_many :rooms, class_name: 'Room', dependent: :destroy

  validates :name, presence: true

end

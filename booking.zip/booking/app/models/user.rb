class User < ApplicationRecord

  has_many :events, class_name: 'Event', dependent: :destroy

  has_many :rooms, class_name: 'Room'

  validates :name, presence: true

end

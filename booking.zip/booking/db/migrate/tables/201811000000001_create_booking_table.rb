class CreateBookingTable < ActiveRecord::Migration[5.0]
  def change
    create_table 'offices' do |t|
      t.string 'name'
    end

    create_table 'departments' do |t|
      t.string 'name'
      t.references :office, foreign_key: true
    end

    create_table 'rooms' do |t|
      t.string 'name'
      t.string 'room_type'
      t.references :department, foreign_key: true
    end

    create_table 'users' do |t|
      t.string 'name'
    end

    create_table 'events' do |t|
      t.string 'event_name'
      t.string 'room_name'
      t.datetime 'start_date'
      t.datetime 'end_date'
      t.references :room, :user, foreign_key: true
      t.timestamp
    end
  end
end

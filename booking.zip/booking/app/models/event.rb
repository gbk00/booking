class Event < ApplicationRecord

  belongs_to :user, class_name: 'User', dependent: :destroy
  belongs_to :room, class_name: 'Room', dependent: :destroy

  validates :event_name, presence: true, length: { minimum: 10 }
  validates :room_name, presence: true, length: { minimum: 10 }
  validates :start_date, presence: true
  validates :end_date, presence: true

  validates_date :end_date, on_or_after: :start_date,
                            on_or_after_message: :on_or_after_start_date
end

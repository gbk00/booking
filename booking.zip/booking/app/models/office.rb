class Office < ApplicationRecord

  has_many :departments, class_name: 'Department', dependent: :destroy

  validates :name, presence: true

end
